package net.hafiz.commentposter;

import android.os.Parcel;
import android.os.Parcelable;

public class NewsItem implements Parcelable {
    private int newsId;
    private String title, description, location, reporterName;
    private String date;

    public NewsItem(int newsId, String title, String location, String description, String date, String reporterName) {
        this.newsId = newsId;
        this.title = title;
        this.location = location;
        this.description = description;
        this.reporterName = reporterName;
        this.date = date;
    }

    public int getNewsId() {
        return newsId;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }

    public String getReporterName() {
        return reporterName;
    }

    public String getDate() {
        return date;
    }

    // Parcelable implementation

    protected NewsItem(Parcel in) {
        newsId = in.readInt();
        title = in.readString();
        description = in.readString();
        location = in.readString();
        reporterName = in.readString();
        date = in.readString();
    }

    public static final Creator<NewsItem> CREATOR = new Creator<NewsItem>() {
        @Override
        public NewsItem createFromParcel(Parcel in) {
            return new NewsItem(in);
        }

        @Override
        public NewsItem[] newArray(int size) {
            return new NewsItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(newsId);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(location);
        dest.writeString(reporterName);
        dest.writeString(date);
    }
}