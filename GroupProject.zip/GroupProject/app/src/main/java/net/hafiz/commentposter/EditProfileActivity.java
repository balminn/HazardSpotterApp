package net.hafiz.commentposter;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

public class EditProfileActivity extends AppCompatActivity {

    private EditText etName, etEmail;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        btnSave = findViewById(R.id.btn_save);

        // Retrieve the GoogleSignInAccount passed from MainActivity
        GoogleSignInAccount account = getIntent().getParcelableExtra("googleSignInAccount");

        // Populate the EditText fields with the user's current name and email
        etName.setText(account.getDisplayName());
        etEmail.setText(account.getEmail());

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the updated name and email
                String updatedName = etName.getText().toString().trim();
                String updatedEmail = etEmail.getText().toString().trim();

                // Perform the update operation (you can send this data to the server)

                // Optionally, you can update the display name in the GoogleSignInAccount
                account.getDisplayName(); // Update display name here
                // Update the email address associated with the account if needed
                account.getEmail(); // Update email address here

                // Finish the activity
                finish();
            }
        });
    }
}
