package net.hafiz.commentposter;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class ReportActivity extends AppCompatActivity {

    private NewsItem selectedNews;

    private String email;
    private String userId;


    //    private String URL = "http://192.168.68.114/HazardSpotter/report_api.php"; // Replace with your API URL
    private String URL = "http://192.168.80.97/HazardSpotter/report_api.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        email = account.getEmail();
        userId = account.getId();


        // Retrieve the selectedNews from the intent
        selectedNews = getIntent().getParcelableExtra("selectedNews");
//        email = account.getEmail();



        // Display the details of the selectedNews in the UI
        TextView tvTitle = findViewById(R.id.tvNewsTitle);
        TextView tvDescription = findViewById(R.id.tvNewsDescription);
        TextView tvLocation = findViewById(R.id.tvNewsLocation);
        TextView tvDate = findViewById(R.id.tvNewsDate);
        TextView tvReporterName = findViewById(R.id.tvReporterName);

        tvTitle.setText(selectedNews.getTitle());
        tvDescription.setText(selectedNews.getDescription());
        tvLocation.setText("Location: " + selectedNews.getLocation());
        tvDate.setText("Date: " + selectedNews.getDate());
        tvReporterName.setText("Reporter: " + selectedNews.getReporterName());

        // Load the image using the image_url (you can use any image loading library like Picasso or Glide)
        // For example, if you're using Picasso:
        ImageView ivNewsImage = findViewById(R.id.ivNewsImage);
//        Picasso.get().load(selectedNews.getImageUrl()).into(ivNewsImage);

        EditText etReportComments = findViewById(R.id.etReportComments);
        Button btnSubmitReport = findViewById(R.id.btnSubmitReport);

        btnSubmitReport.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Get the report comments entered by the user
                String reportComments = etReportComments.getText().toString().trim();


                Log.d("onClickReportAct", "Email: " + email);

                // Make the API call to submit the comment to the backend
                submitCommentToBackend(userId, reportComments, email);
            }
        });
    }

    private void submitCommentToBackend(String userId, String comments, String email) {

        Log.d("DebugData", "User ID: " + userId);
        Log.d("DebugData", "Comments: " + comments);
        Log.d("DebugData", "Email: " + email);
        Log.d("DebugData", "Selected News ID: " + selectedNews.getNewsId());
        // Create a RequestQueue using Volley
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Response", response); // Add this line to check the response in logcat
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            String message = jsonObject.getString("message");

                            if (success) {
                                Toast.makeText(ReportActivity.this, message, Toast.LENGTH_SHORT).show();
                                finish(); // Finish the ReportActivity and return to the previous activity (i.e., NewsActivity)
                            } else {
                                Toast.makeText(ReportActivity.this, "Failed: " + message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(ReportActivity.this, "Error parsing JSON response", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ReportActivity.this, "Error submitting report!", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("date", getCurrentDateTime()); // Replace with your method to get the current date and time
                params.put("comments", comments);
                params.put("news_id", String.valueOf(selectedNews.getNewsId())); // Use the selectedNewsId instead of selectedNews.getNewsId()
                params.put("user_id", String.valueOf(userId)); // Replace with the actual user_id

                // Add other parameters as needed for your API request

                return params;
            }
        };

        // Add the request to the RequestQueue
        queue.add(stringRequest);
    }



    // Method to get the current date and time in the desired format (you can replace this with your implementation)
    private String getCurrentDateTime() {
        // Implement your logic to get the current date and time in the desired format
        // For example:
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());

        //return ""; // Replace this with the actual date and time
    }
}