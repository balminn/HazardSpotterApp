package net.hafiz.commentposter;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainMenuActivity extends AppCompatActivity implements View.OnClickListener {

    RequestQueue queue;
    GoogleSignInClient mGoogleSignInClient;

    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);

        // Retrieve the email value from the intent
        String email = account.getEmail();
        Log.d("MainMenuActivity", "Email: " + email);

        // Initialize GoogleSignInOptions
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        queue = Volley.newRequestQueue(getApplicationContext());

        Button btnViewNews = findViewById(R.id.btnViewNews);
        Button btnAboutUs = findViewById(R.id.btnAboutUs);
        btnAboutUs.setOnClickListener(this);

//        Button btnEditProfile = findViewById(R.id.btnEditProfile);
        Button btnLogout = findViewById(R.id.btnLogout);

        btnViewNews.setOnClickListener(this);
//        btnEditProfile.setOnClickListener(this);
        btnLogout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnViewNews:
                viewNews();
                break;
            case R.id.btnAboutUs:
                aboutUs();
                break;
            case R.id.btnLogout:
                logout();
                break;
        }
    }

    private void aboutUs() {
        // Add a debug log to check if the method is executed
        Log.d("AboutUsActivity", "About Us button clicked");

        Intent intent = new Intent(MainMenuActivity.this, AboutUsActivity.class);
        startActivity(intent);
    }


    private List<NewsItem> newsList = new ArrayList<>();



    private void viewNews() {
        // Assuming you have an API endpoint that returns the news data in JSON format
        String newsApiUrl = "http://192.168.80.97/HazardSpotter/view_api.php";

        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.GET, newsApiUrl, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray newsArray = response.getJSONArray("data");
                            newsList.clear();
                            for (int i = 0; i < newsArray.length(); i++) {
                                JSONObject newsJson = newsArray.getJSONObject(i);
                                int newsId = newsJson.getInt("news_id"); // Get the news_id from the JSON response
                                String title = newsJson.getString("title");
                                String location = newsJson.getString("location");
                                String description = newsJson.getString("description");
                                String date = newsJson.getString("date");
                                String reporterName = newsJson.getString("reporter_name");

                                NewsItem newsItem = new NewsItem(newsId, title, location, description, date, reporterName); // Pass the news_id to the constructor
                                newsList.add(newsItem);
                            }

                            // Start the NewsActivity and pass the newsList
                            Intent intent = new Intent(MainMenuActivity.this, NewsActivity.class);
                            intent.putParcelableArrayListExtra("newsList", (ArrayList<? extends Parcelable>) newsList);
                            intent.putExtra("email", email);
                            startActivity(intent);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(MainMenuActivity.this, "Error parsing JSON response", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Toast.makeText(MainMenuActivity.this, "Error fetching news data", Toast.LENGTH_SHORT).show();
                    }
                });

        // Add the JSON request to the Volley request queue
        queue.add(jsonRequest);
    }


    private void editProfile() {
        // Example code to start the EditProfileActivity (replace with your implementation)
        Intent intent = new Intent(this, EditProfileActivity.class);
        startActivity(intent);
    }

    private void logout() {
        // Sign out the user from Google account
        mGoogleSignInClient.signOut()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        // Redirect the user back to the login screen (MainActivity)
                        Intent intent = new Intent(MainMenuActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish(); // Finish the MainMenuActivity so that the user can't go back to it after logging out.
                    }
                });
    }
}