package net.hafiz.commentposter;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class NewsActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);


        List<NewsItem> newsList = getIntent().getParcelableArrayListExtra("newsList");

        if (newsList != null && !newsList.isEmpty()) {
            ListView listView = findViewById(R.id.listView);
            ArrayAdapter<NewsItem> adapter = new ArrayAdapter<NewsItem>(this, android.R.layout.simple_list_item_2, android.R.id.text1, newsList) {
                @Override
                public View getView(int position, View convertView, ViewGroup parent) {
                    View view = super.getView(position, convertView, parent);
                    TextView text1 = view.findViewById(android.R.id.text1);
                    TextView text2 = view.findViewById(android.R.id.text2);

                    NewsItem newsItem = getItem(position);
                    text1.setText(newsItem.getTitle());
                    text2.setText(newsItem.getDescription());

                    return view;
                }
            };
            listView.setAdapter(adapter);

            // Set the OnItemClickListener for the listView
            listView.setOnItemClickListener((parent, view, position, id) -> {
                NewsItem selectedNews = newsList.get(position);
                String email = getIntent().getStringExtra("email");
                int newsId = selectedNews.getNewsId(); // Get the selected news_id

                // Start the report submission activity and pass the newsId and selectedNews
                Intent intent = new Intent(NewsActivity.this, ReportActivity.class);
                intent.putExtra("newsId", newsId);
                intent.putExtra("selectedNews", selectedNews); // Pass the selectedNews object
                intent.putExtra("email", email);
                startActivity(intent);
            });
        }
    }
}