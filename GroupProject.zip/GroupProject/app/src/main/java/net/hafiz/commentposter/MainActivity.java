package net.hafiz.commentposter;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    GoogleSignInOptions gso;
    GoogleSignInClient mGoogleSignInClient;

    String email, userId;
    private static final int RC_SIGN_IN = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set the dimensions of the sign-in button.
        SignInButton signInButton = findViewById(R.id.sign_in_button);
        signInButton.setSize(SignInButton.SIZE_STANDARD);
        signInButton.setOnClickListener(this);

        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        // Check for existing Google Sign In account, if the user is already signed in
        // the GoogleSignInAccount will be non-null.
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);

        if (account == null) {
            // User has not signed in yet, show a message.
            Toast.makeText(this, "Please sign in with your Google account.", Toast.LENGTH_SHORT).show();
        } else {
            // User is already signed in, show the Main Menu page and save user data.
            saveUserData(account);
            showMainMenu(account);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.sign_in_button) {
            signIn();
        }
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            // Signed in successfully, show authenticated UI.
            Toast.makeText(this, "Welcome, " + account.getDisplayName(), Toast.LENGTH_SHORT).show();
            saveUserData(account); // Save user data to the server
            String email = account.getEmail();
            Log.d("handleSignIn", "Email: " + email);
            showMainMenu(account);

        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Toast.makeText(this, "Sign in failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMainMenu(GoogleSignInAccount account) {
        String email = account.getEmail();
        Log.d("showMainMenu", "Email: " + email);

        Intent intent = new Intent(this, MainMenuActivity.class);
        intent.putExtra("googleSignInAccount", account); // Pass the GoogleSignInAccount instance
        intent.putExtra("email", email);
        startActivity(intent);
        finish(); // Finish the MainActivity so that the user can't go back to it after signing in.
    }

    private void saveUserData(GoogleSignInAccount account) {
        // Get user information
        String userId = account.getId(); // Unique user ID provided by Google
        String name = account.getDisplayName(); // User's display name
        String email = account.getEmail(); // User's email address

        // Execute AsyncTask to get the IP address and user agent
        new GetIPAddressAndUserAgentTask().execute(userId, name, email);
    }

    // AsyncTask to get the user's IP address and user agent
    private class GetIPAddressAndUserAgentTask extends AsyncTask<String, Void, String[]> {
        private String userId;
        private String name;
        private String email;

        @Override
        protected String[] doInBackground(String... params) {
            userId = params[0];
            name = params[1];
            email = params[2];

            String ipAddress = getIPAddress();
            String userAgent = ""; // Initialize to empty string for now, we'll set it later

            return new String[]{ipAddress, userAgent};
        }

        @Override
        protected void onPostExecute(String[] results) {
            String ipAddress = results[0];
            String userAgent = getUserAgent(); // Now call getUserAgent() on the main thread

            // Continue with saving user data, including the IP address and user agent
            saveUserDataToDB(name, email, ipAddress, userAgent);
        }
    }


    private String getIPAddress() {
        try {
            URL url = new URL("https://api.ipify.org?format=json");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            reader.close();

            JSONObject jsonObject = new JSONObject(stringBuilder.toString());
            return jsonObject.getString("ip");

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            return "";
        }
    }

    private String getUserAgent() {
        String userAgent = "";
        try {
            WebView webView = new WebView(this);
            userAgent = webView.getSettings().getUserAgentString();
            Log.d("UserAgent", "User Agent: " + userAgent); // Add this debug log
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userAgent;
    }




    private void saveUserDataToDB(String name, String email, String ipAddress, String userAgent) {

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        userId = account.getId();
        // Generate a random user_id
        userId = account.getId();
        // Create a RequestQueue using Volley
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://192.168.80.97/HazardSpotter/user_data_api.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the server response if needed
                        Log.d("SaveUserData", "Response: " + response); // Add this debug log
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle the error if the request fails
                        error.printStackTrace();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", userId);
                params.put("name", name);
                params.put("email", email);
                params.put("ip_address", ipAddress);
                params.put("user_agent", userAgent);
                // Add other parameters as needed for your API request

                return params;
            }
        };



        // Add the request to the RequestQueue
        queue.add(stringRequest);

        // Log the data being sent to the server for debugging
        Log.d("SaveUserData", "User ID: " + userId);
        Log.d("SaveUserData", "Name: " + name);
        Log.d("SaveUserData", "Email: " + email);
        Log.d("SaveUserData", "IP Address: " + ipAddress);
        Log.d("SaveUserData", "User Agent: " + userAgent);
    }

    private String generateRandomUserId() {
        // Assuming you want a random positive integer
        Random random = new Random();
        int userId = random.nextInt(Integer.MAX_VALUE - 1) + 1;
        return String.valueOf(userId);
    }



}